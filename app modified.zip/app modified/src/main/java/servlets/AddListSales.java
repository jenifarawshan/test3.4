package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.ProductDAO;
import DAO.SalesDAO;
import DTO.ProductDTO;
import DTO.SalesDTO;
import utils.DB;

public class AddListSales extends HttpServlet {
    private SalesDAO salesDAO;
    private ProductDAO productDAO;

    // Constructor to initialize the SalesDAO
    public AddListSales() throws ClassNotFoundException, SQLException {
        Connection conn = DB.getConnection();
        salesDAO = new SalesDAO(conn);
        productDAO = new ProductDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");
        // Implement logic to list sales for today and populate the JSP
        try {
            // Get the current date in the format "yyyy-MM-dd"
        	
        	String currentDate = java.time.LocalDate.now().toString();

            // Call listSales with the date parameter
            List<SalesDTO> salesList = salesDAO.listSales(currentDate);

            // Set the salesList in the request to be used in the JSP
            request.setAttribute("salesList", salesList);
            request.setAttribute("currentDate", currentDate);
            
            
            

            // Get the list of products from the ProductDAO ProductDAO
            List<ProductDTO> productList = productDAO.getProducts(null); // Pass null to get all products
            request.setAttribute("productList", productList);
            
            
         // Check if the temporary table data is available in the session
            HttpSession session = request.getSession();
            List<SalesDTO> tempSalesList = (List<SalesDTO>) session.getAttribute("tempSalesList");
            request.setAttribute("tempSalesList", tempSalesList);

            // Forward the request to the JSP page
            request.getRequestDispatcher("/WEB-INF/add_list_sales.jsp").forward(request, response);
           

        } catch (ClassNotFoundException | SQLException e) {
            // Handle any exceptions appropriately
            e.printStackTrace();
            request.setAttribute("errorMessage",
                    "An error occurred: " + e.getMessage());
        } finally {
            // Forward the request to the JSP page
            request.getRequestDispatcher("/WEB-INF/add_list_sales.jsp")
                    .forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Implement logic to add new sales data
        try {
            int productCode = Integer.parseInt(request.getParameter("productCode"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            HttpSession session = request.getSession();
            List<SalesDTO> tempSalesList = (List<SalesDTO>) session.getAttribute("tempSalesList");

            // Check if the product already exists in the temporary table
            boolean productExists = false;
            for (SalesDTO tempSales : tempSalesList) {
                if (tempSales.getProductCode() == productCode) {
                    // Product exists, update the quantity
                    tempSales.setQuantity(tempSales.getQuantity() + quantity);
                    productExists = true;
                    break;
                }
            }

            if (!productExists) {
                // Product doesn't exist, add a new entry to the temporary table
                ProductDTO product = productDAO.getProductByCode(productCode);
                SalesDTO tempSales = new SalesDTO();
                tempSales.setProductCode(productCode);
                tempSales.setProductName(product.getProductName());
                tempSales.setQuantity(quantity);
                tempSalesList.add(tempSales);
            }

            // Update the temp sales list in the session
            session.setAttribute("tempSalesList", tempSalesList);

            // Redirect to doGet to display the updated sales list
            response.sendRedirect(request.getContextPath() + "/sales");

        } catch (NumberFormatException | SQLException e) {
            // Handle any exceptions appropriately
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            doGet(request, response); // Redirect to doGet with error message
        }
    }
}