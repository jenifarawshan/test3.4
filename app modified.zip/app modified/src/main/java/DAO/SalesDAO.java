package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DTO.ProductDTO;
import DTO.SalesDTO;

public class SalesDAO {
    private Connection connection;

    public SalesDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean addSales(String date, int productCode, int quantity) throws SQLException {
        // Check if the product already exists for the given date
        String checkQuery = "SELECT COUNT(*) FROM t_sales WHERE sales_date=? AND product_code=?";
        PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
        checkStatement.setString(1, date);
        checkStatement.setInt(2, productCode);
        ResultSet checkResult = checkStatement.executeQuery();

        if (checkResult.next() && checkResult.getInt(1) > 0) {
            // Product already exists for the given date, update the quantity
            String updateQuery = "UPDATE t_sales SET quantity = quantity + ? WHERE sales_date=? AND product_code=?";
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setInt(1, quantity);
            updateStatement.setString(2, date);
            updateStatement.setInt(3, productCode);
            updateStatement.executeUpdate();
            return true;
        } else {
            // Product doesn't exist for the given date, add a new entry
            String insertQuery = "INSERT INTO t_sales(sales_date, product_code, quantity, register_datetime, update_datetime) values(?, ?, ?, NOW(), NOW())";
            PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
            insertStatement.setString(1, date);
            insertStatement.setInt(2, productCode);
            insertStatement.setInt(3, quantity);
            insertStatement.executeUpdate();
            return true;
        }
    }

    public void updateSales(String date, int productCode, int quantity) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("UPDATE t_sales SET quantity=?, update_datetime=NOW() WHERE sales_date=? AND product_code=?");
        preparedStatement.setInt(1, quantity);
        preparedStatement.setString(2, date);
        preparedStatement.setInt(3, productCode);
        preparedStatement.executeUpdate();
    }

    public List<SalesDTO> getTemporarySalesData(List<SalesDTO> tempSalesList, int productCode) {
        List<SalesDTO> tempSalesData = new ArrayList<>();
        for (SalesDTO tempSales : tempSalesList) {
            if (tempSales.getProductCode() == productCode) {
                tempSalesData.add(tempSales);
            }
        }
        return tempSalesData;
    }
    
    public ProductDTO getProductByCode(int productCode) throws SQLException {
        String query = "SELECT * FROM m_product WHERE product_code = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();
    
        if (resultSet.next()) {
            ProductDTO product = new ProductDTO();
            product.setProductCode(resultSet.getInt("product_code"));
            product.setProductName(resultSet.getString("product_name"));
            // Set other product properties
    
            preparedStatement.close(); // Close the statement
            resultSet.close(); // Close the result set
    
            return product;
        } else {
            preparedStatement.close(); // Close the statement
            resultSet.close(); // Close the result set
            return null; // Product not found
        }
    }
    

    public boolean addTemporarySalesData(List<SalesDTO> tempSalesData) throws SQLException {
        String insertQuery = "INSERT INTO temporary_sales (product_code, quantity) VALUES (?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);

        for (SalesDTO tempSales : tempSalesData) {
            preparedStatement.setInt(1, tempSales.getProductCode());
            preparedStatement.setInt(2, tempSales.getQuantity());
            preparedStatement.executeUpdate();
        }

        preparedStatement.close(); // Close the statement
        return true;
    }
    
    public boolean transferTemporarySalesData() throws SQLException {
        String transferQuery = "INSERT INTO t_sales (sales_date, product_code, quantity, register_datetime, update_datetime) "
                + "SELECT NOW(), product_code, quantity, NOW(), NOW() FROM temporary_sales";

        String clearQuery = "DELETE FROM temporary_sales";

        PreparedStatement transferStatement = connection.prepareStatement(transferQuery);
        int transferredRows = transferStatement.executeUpdate();

        PreparedStatement clearStatement = connection.prepareStatement(clearQuery);
        clearStatement.executeUpdate();

        transferStatement.close();
        clearStatement.close();

        return transferredRows > 0;
    }

    

    public void clearTemporarySalesData() throws SQLException {
        String deleteQuery = "DELETE FROM temporary_sales";
        PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
        preparedStatement.executeUpdate();
        preparedStatement.close(); // Close the statement
    }

}
